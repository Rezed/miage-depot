package Airport;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang3.StringUtils;



public class Airline {

	private String name;

	private final Map<String, Flight> flights	= new ConcurrentHashMap<String, Flight>();

	private Airline() {
		super();
	}

	private Airline(String companyName) {
		super();
		this.name = companyName;
	}

	public static Airline getInstance(String companyName) {
		Airline instance = null;
		if (StringUtils.isNotBlank(companyName) && companyName.length() <= 5) {
			instance = new Airline(companyName);
		}
		return instance;
	}

	public Flight findFlight(String flightId) {
		return flights.get(flightId);
	}

	public Flight createFlight(String orig, String desti, int year, int month, int day, String flightId) {
		Flight flight = null;
		if (StringUtils.isNotBlank(orig) && StringUtils.isNotBlank(desti) && !orig.equals(desti)
						&& StringUtils.isNotBlank(flightId)) {
			Calendar date = AirlineUtil.getCalendar(year, month, day);
			SystemManager mananger = SystemManager.getInstance();
			Airport origine = mananger.getAirports().get(orig);
			Airport destination = mananger.getAirports().get(desti);
			if (origine != null && destination != null) {
				flight = Flight.getInstance(flightId, this, origine, destination, date);
				// Ajouter le Vol à la liste des Vols de la company
				this.flights.put(flightId, flight);
			}
		}
		return flight;
	}


	public FlightSection createSection(String flightId, int row, int col, SeatClass seatClass) {
		FlightSection section = null;
		Flight flight = findFlight(flightId);

		if (flight != null && !flight.getFlightSections().containsKey(seatClass) && checkRow(row)
						&& checkColumn(col)) {
			section = FlightSection.getInstance(row, col, seatClass);
			initializeSeats(section, row, col);
			flight.getFlightSections().put(seatClass, section);
		}
		return section;
	}


	private void initializeSeats(FlightSection section, int nbLigne, int nbColumn) {
		for (int row = 1; row <= nbLigne; row++) {
			for (int col = 1; col <= nbColumn; col++) {
				SeatID seatID = SeatID.getInstance(row, AirlineUtil.intToChar(nbColumn));
				Seat seat = Seat.getInstance(seatID);
				section.getSeats().add(seat);
			}
		}
	}

	private boolean checkRow(int row) {
		return row > 0 && row <= 100;
	}

	private boolean checkColumn(int col) {
		return col > 0 && col <= 10;
	}

	/**
	 * Trouve  tous  les  vols sur lesquels il existe encore des sièges disponibles, entre les aeroports de départ et d’arrivée.
	 * @param orig
	 * @param dest
	 * @return
	 */
	public List<Flight> getAvailableFlights(Airport orig, Airport dest) {
		List<Flight> availableFlights = new ArrayList<Flight>();
		for (Flight flight : getFlights()) {
			if (flight.getOrigine().equals(orig) && flight.getDestination().equals(dest) && flight.hasSeats()) {
				// S'il existe un siège disponible
				availableFlights.add(flight);
			}
		}
		return availableFlights;
	}

	public Boolean bookFlight(String flightId, SeatClass seatClass, int row, char col) {
		Flight flight = findFlight(flightId);
		Boolean isBooked = Boolean.FALSE;
		if (flight != null) {
			FlightSection flightSection = flight.findFlightSection(seatClass);
			if (flightSection != null) {
				SeatID seatID = SeatID.getInstance(row, col);
				isBooked = flightSection.bookSeat(seatID);
			}
		}
		return isBooked;
	}

	public String getName() {
		return name;
	}

	public List<Flight> getFlights() {
		List<Flight> listFlights = new ArrayList<Flight>();
		final Set<Entry<String, Flight>> entries = this.flights.entrySet();

		for (Entry<String, Flight> entry : entries) {
			listFlights.add(entry.getValue());
		}
		return listFlights;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}
          @Override
    public String toString() {
        return "Airline{" +
                "identifiant='" + name+
                "'}";
    }

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Airline other = (Airline) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
	
	

}
