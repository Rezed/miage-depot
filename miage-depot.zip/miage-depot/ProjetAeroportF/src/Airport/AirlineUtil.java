package Airport;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class AirlineUtil {

	/**
	 * Permet de convertir (year, month, day) to a calendar object
	 * 
	 * @param year
	 * @param month
	 * @param day
	 * @return
	 */
	public static Calendar getCalendar(int year, int month, int day) {
		Calendar calendar = null;
		try {
			@SuppressWarnings("deprecation")
			Date date = new Date(year, month, day);
			calendar = Calendar.getInstance();
			calendar.setTime(date);
		} catch (Exception e) {
			// TODO: handle exception
		}

		return calendar;
	}

	public static char intToChar(int valeur) {
		return (char) (valeur + (int) 'A' - 1);
	}

	public static List<Object> convertMapToList(Map map) {
		List<Object> listFlights = new ArrayList<Object>();
		final Set<Entry<String, Object>> entries = map.entrySet();

		for (Entry<String, Object> entry : entries) {
			listFlights.add(entry.getValue());
		}
		return listFlights;
	}

}
