package Airport;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang3.StringUtils;

public class Flight {

    private String flightId;
    private Airline airline;
    private Airport origine;
    private Airport destination;
    private Calendar date;

    private final Map<SeatClass, FlightSection> flightSections = new ConcurrentHashMap<SeatClass, FlightSection>();

    private Flight() {
        super();
    }

    private Flight(String flightId, Airline airline, Airport origine, Airport destination, Calendar date) {
        super();
        this.flightId = flightId;
        this.airline = airline;
        this.origine = origine;
        this.destination = destination;
        this.date = date;
    }

    public static Flight getInstance(String flightId, Airline airline, Airport origine, Airport destination,
            Calendar date) {
        Flight instance = null;
        if (StringUtils.isNotBlank(flightId)) {
            instance = new Flight(flightId, airline, origine, destination, date);
        }
        return instance;
    }

    public Boolean hasSection() {
        return !getFlightSections().isEmpty();
    }

    public Boolean hasSeats() {
        return !getFlightSections().isEmpty();
    }

    public Boolean hasAvailableSeats() {
        Boolean hasAvailableSeat = Boolean.FALSE;
        for (FlightSection flightSection : getFlightSections().values()) {
            if (flightSection.hasAvailableSeats()) {
                hasAvailableSeat = Boolean.TRUE;
                break;
            }
        }
        return hasAvailableSeat;
    }

    public String getFlightId() {
        return flightId;
    }

    public Map<SeatClass, FlightSection> getFlightSections() {
        return this.flightSections;
    }

    public FlightSection findFlightSection(SeatClass seatClass) {
        return getFlightSections().get(seatClass);
    }

    public Airline getAirline() {
        return airline;
    }

    public void setAirline(Airline airline) {
        this.airline = airline;
    }

    public Airport getOrigine() {
        return origine;
    }

    public void setOrigine(Airport origine) {
        this.origine = origine;
    }

    public Airport getDestination() {
        return destination;
    }

    public void setDestination(Airport destination) {
        this.destination = destination;
    }

    public Calendar getDate() {
        return date;
    }

    public void setDate(Calendar date) {
        this.date = date;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((airline == null) ? 0 : airline.hashCode());
        result = prime * result + ((date == null) ? 0 : date.hashCode());
        result = prime * result + ((destination == null) ? 0 : destination.hashCode());
        result = prime * result + ((flightId == null) ? 0 : flightId.hashCode());
        result = prime * result + ((origine == null) ? 0 : origine.hashCode());
        return result;
    }

    private String afficheSection() {
        String affichage = "";
        Set<SeatClass> clef = getSectionMap().keySet();
        Iterator<SeatClass> it = clef.iterator();
        while (it.hasNext()) {
            Object sec = it.next();
            affichage += getSectionMap().get(sec).toString() + "\n";
        }

        return affichage;
    }

    private String afficheDate() {
        return date.getTime().getDay() + "/" +date.getTime().getMonth() + "/" + date.getTime().getYear();
    }

    @Override
    public String toString() {
        return "* Details du vol " + flightId + " { \n"
                + "   - date=" + afficheDate()
                + ", airline=" + airline.getName()
                + ", origine=" + origine.getCode()
                + ", destination=" + destination.getCode()
                + ", \n" + afficheSection()
                + "}";
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Flight other = (Flight) obj;
        if (airline == null) {
            if (other.airline != null) {
                return false;
            }
        } else if (!airline.equals(other.airline)) {
            return false;
        }
        if (date == null) {
            if (other.date != null) {
                return false;
            }
        } else if (!date.equals(other.date)) {
            return false;
        }
        if (destination == null) {
            if (other.destination != null) {
                return false;
            }
        } else if (!destination.equals(other.destination)) {
            return false;
        }
        if (flightId == null) {
            if (other.flightId != null) {
                return false;
            }
        } else if (!flightId.equals(other.flightId)) {
            return false;
        }
        if (origine == null) {
            if (other.origine != null) {
                return false;
            }
        } else if (!origine.equals(other.origine)) {
            return false;
        }
        return true;
    }

    public Map<SeatClass, FlightSection> getSectionMap() {
        return flightSections;
    }

}
