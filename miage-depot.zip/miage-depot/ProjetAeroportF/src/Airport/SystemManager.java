package Airport;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class SystemManager {

    private final Map<String, Airline> airlines = new ConcurrentHashMap<String, Airline>();

    private final Map<String, Airport> airports = new ConcurrentHashMap<String, Airport>();
    private final Map<String, Flight> volMap = new HashMap();

    private SystemManager() {
    }

    /**
     * affiche toute l’information concernant tous les objets (aeroports,
     * compagnies, vols, sièges, ...) dans le système.
     */
    public void displaySystemDetails() {
       
        System.out.println("Aéroports :");
      
        Set<String> listeClef = airports.keySet();
        Iterator it_aero = listeClef.iterator();
        while (it_aero.hasNext()) {
            Object aero = it_aero.next();
            System.out.println(airports.get(aero));
        }
        System.out.println("-----------------------------");
        
        System.out.println("Compagnies :");
        
        Set<String> clef = airlines.keySet();
        Iterator it_air = clef.iterator();
        while (it_air.hasNext()) {
            Object ligne = it_air.next();
            System.out.println(airlines.get(ligne));
        }
        System.out.println("-----------------------------");
        
        
        System.out.println("Vols :");
        
        Set<String> setClef = volMap.keySet();
        Iterator it_vol = setClef.iterator();
        while (it_vol.hasNext()) {
            Object vol = it_vol.next();
            System.out.println(volMap.get(vol));
        }
        
    System.out.println("-----------------------------");
        
    }

    public List<Flight> findAvailableFlights(String orig, String desti) {
        List<Flight> availableFlights = new ArrayList<Flight>();

        if (this.airports.containsKey(orig) && this.airports.containsKey(desti)) {
            Airport origine = airports.get(orig);
            Airport destination = airports.get(desti);
            for (Airline airline : airlines.values()) {
                availableFlights.addAll(airline.getAvailableFlights(origine, destination));
            }
        }
        return availableFlights;
    }

    public FlightSection createSection(String companyName, String flightId, int row, int col, SeatClass seat) {
        FlightSection flightSection = null;
        if (this.airlines.containsKey(companyName)) {
            Airline airline = airlines.get(companyName);
            flightSection = airline.createSection(flightId, row, col, seat);
        }
        return flightSection;
    }

    public Flight createFlight(String companyName, String orig, String desti, int year, int month, int day,
            String flightId) {
        Flight flight = null;
        if (this.airlines.containsKey(companyName)) {
            Airline airline = this.airlines.get(companyName);

            
            flight = airline.createFlight(orig, desti, year, month, day, flightId);
            if (flight != null) {
                this.volMap.put(flightId, flight);
            }
        }

        return flight;
    }

    public Airport createAirport(String airportName) {
        Airport airport = null;
        if (!this.airports.containsKey(airportName)) {
            airport = Airport.getInstance(airportName);
            if (airport != null) {
                this.airports.put(airportName, airport);

            }
        }
        return airport;
    }

    public Airline createAirline(String companyName) {
        Airline airline = null;
        if (!this.airlines.containsKey(companyName)) {
            airline = Airline.getInstance(companyName);
            if (airline != null) {
                this.airlines.put(companyName, airline);

            }
        }
        return airline;
    }

    public Boolean bookSeat(String companyName, String flightId, SeatClass seatClass, int row, char col) {
        Boolean isBooked = Boolean.FALSE;
        if (this.airlines.containsKey(companyName)) {
            Airline airline = airlines.get(companyName);
            isBooked = airline.bookFlight(flightId, seatClass, row, col);
        }
        return isBooked;
    }

    public Map<String, Airline> getAirlines() {
        return airlines;
    }

    public Map<String, Airport> getAirports() {
        return airports;
    }

    /**
     * Point d'accès pour l'instance unique du singleton
     */
    public static SystemManager getInstance() {
        return SystemManagerHolder.instance;
    }

    /**
     * Holder
     */
    private static class SystemManagerHolder {
        /**
         * Instance unique non préinitialisée
         */
        private final static SystemManager instance = new SystemManager();
    }

}
