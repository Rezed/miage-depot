package Airport;

public class SeatID {

	private Integer	row;
	private char	column;

	private SeatID() {
		super();
	}

	private SeatID(Integer row, char column) {
		super();
		this.row = row;
		this.column = column;
	}

	public static SeatID getInstance(Integer row, char column) {
		SeatID instance = new SeatID(row, column);
		return instance;
	}

	public Integer getRow() {
		return row;
	}

	public void setRow(Integer row) {
		this.row = row;
	}

	public char getColumn() {
		return column;
	}

	public void setColumn(char column) {
		this.column = column;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + column;
		result = prime * result + ((row == null) ? 0 : row.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SeatID other = (SeatID) obj;
		if (column != other.column)
			return false;
		if (row == null) {
			if (other.row != null)
				return false;
		} else if (!row.equals(other.row))
			return false;
		return true;
	}

    @Override
    public String toString() {
        return "SeatID{" + "row=" + row + ", column=" + column + '}';
    }


}
