package Airport;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;



public class FlightSection {

	private SeatClass section= null;
	private int nbLigne;
	private int nbColumn;
	private final List<Seat> seats	= new ArrayList<Seat>();

	private FlightSection() {
		super();
	}

	private FlightSection(int nbLigne, int nbColumn, SeatClass seatClass) {
		super();
		this.nbLigne = nbLigne;
		this.nbColumn = nbColumn;
		this.section = seatClass;
	}

	public static FlightSection getInstance(int row, int col, SeatClass seatClass) {
		FlightSection instance = new FlightSection(row, col, seatClass);
		return instance;
	}

	public Boolean hasAvailableSeats() {
		Boolean hasAvailableSeat = Boolean.FALSE;
		for (Seat seat : getSeats()) {
			if (!seat.getIsBooked()) {
				hasAvailableSeat = Boolean.TRUE;
				break;
			}
		}
		return hasAvailableSeat;
	}

	/**
	 * Réserver le premier siège disponible.
	 * @return
	 */
	public Boolean bookSeat() {
		Boolean isBooked = Boolean.FALSE;
		if (hasAvailableSeats()) {
			for (Seat seat : getSeats()) {
				if (!seat.getIsBooked()) {
					seat.setIsBooked(Boolean.TRUE);
					isBooked = Boolean.TRUE;
					break;
				}
			}
		}
		return isBooked;
	}

	/**
	 * réserve un siège dont la position est indiquée par row et col 
	 * @param sId
	 * @return
	 */
	public Boolean bookSeat(SeatID sId) {
		Boolean isBooked = Boolean.FALSE;
		for (Seat seat : getSeats()) {
			// bloc synchronisé
			synchronized (seat) {
				if (seat.getSeatNum().equals(sId) && !seat.getIsBooked()) {
					seat.setIsBooked(Boolean.TRUE);
					isBooked = Boolean.TRUE;
					break;
				}
			}
		}
		return isBooked;
	}

        private String afficheSiege()
    {
        String affichage= "Sièges : ";
      
        Iterator<Seat> it = seats.iterator();
        while(it.hasNext())
        {
            Seat seat = it.next();
            affichage+="\n {"+section.getName()+seat.toString()+"}";
        }

        return affichage;
    }
	public SeatClass getSection() {
		return section;
	}

	public List<Seat> getSeats() {
		return this.seats;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + nbColumn;
		result = prime * result + nbLigne;
		result = prime * result + ((section == null) ? 0 : section.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FlightSection other = (FlightSection) obj;
		if (nbColumn != other.nbColumn)
			return false;
		if (nbLigne != other.nbLigne)
			return false;
		if (section != other.section)
			return false;
		return true;
	}

    @Override
    public String toString() {
        return "   {" + "section=" + section.getName() + " : "+ afficherSeat() + "}";
    }

    private String afficherSeat() {
        StringBuilder sb = new StringBuilder();
         for(Seat seat : seats){
             sb.append(seat.toString());
         }
        return sb.toString();
    }
        	
}
