package Airport;

public enum SeatClass {
	FIRST("First"), BUSI("Business"), ECO("Economy");
	private String	name;

	SeatClass(String name) {
		this.name = name;
	}

	public String getName() {
		return this.name();
	}

}
