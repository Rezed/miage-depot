package Airport;

public class Seat {
	private SeatID seatNum = null;
	private Boolean isBooked = Boolean.FALSE;
	
	private Seat() {
		super();
	}
	
	private Seat(SeatID seatNum) {
		super();
		this.seatNum =seatNum;
		this.isBooked = false;
	}

	public static Seat getInstance(SeatID seatNum) {
		Seat instance = new Seat(seatNum);	
		return instance;
	}

	public SeatID getSeatNum() {
		return seatNum;
	}

	public void setSeatNum(SeatID seatNum) {
		this.seatNum = seatNum;
	}

	public Boolean getIsBooked() {
		return isBooked;
	}

	public void setIsBooked(Boolean isBooked) {
		this.isBooked = isBooked;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((seatNum == null) ? 0 : seatNum.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Seat other = (Seat) obj;
		if (seatNum == null) {
			if (other.seatNum != null)
				return false;
		} else if (!seatNum.equals(other.seatNum))
			return false;
		return true;
	}

    @Override
    public String toString() {
        return "\n       - Seat{" + "seatNum=" + seatNum.toString() + ", isBooked=" + isBooked + '}';
    }
	
	

}
