
import Airport.Airline;
import Airport.SystemManager;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;





public class FirstTest {
	protected SystemManager	systemManager;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		systemManager = SystemManager.getInstance();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testCalculer() throws Exception {
		assertEquals(Airline.getInstance("AZER"), systemManager.createAirline("AZR"));
		assertEquals(Airline.getInstance("qsdf"), systemManager.createAirline("qsdf"));
	}

}
